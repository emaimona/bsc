var termsRadio = document.getElementById("terms");
var loginBtn = document.getElementById("btnid");


loginBtn.addEventListener("click", function() {
    if (!termsRadio.checked) {
        alert("Você deve aceitar os termos e serviços!");
    } else {
        var name = document.getElementById("username");
        alert("Seja Benvindo "+name.value + "!");
    }
});


termsRadio.addEventListener("click", function() {
    if (termsRadio.checked) {
        alert("Você aceitou os termos e serviços!");
    }
});
