package travel;

public enum Destination {
    BERLIN, ROME, AMSTERDAM, PARIS, HELSINKI;
}
